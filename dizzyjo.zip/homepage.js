new Vue({
    el: '#homepage',
    data: {
        slides: 1
    },
    components: {
        'carousel-3d': Carousel3d.Carousel3d,
        'slide': Carousel3d.Slide
    }
})